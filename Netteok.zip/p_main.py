import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5 import uic, QtCore, QtGui, QtWidgets
from winreg import *
import dpkt, pcap, pcapsave, pcapload, proxy_on, proxy_off, run, binascii, cut, socket
from interface import *
from _thread import *
from protocol import *
from threading import Thread

#UI파일 연결
#단, UI파일은 Python 코드 파일과 같은 디렉토리에 위치해야한다.
form_class_main = uic.loadUiType("untitled.ui")[0]
# form_class_iface = uic.loadUiType("untitlediface.ui")[0]
#화면을 띄우는데 사용되는 Class 선언

class WindowClassMain(QMainWindow, form_class_main):
    def __init__(self, parent=None) :
        super(WindowClassMain, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle("Netteock")
        self.setWindowIcon(QIcon("./icon/네떡.png"))
        self.packet_start.setDisabled(True)
        self.packet_stop.setDisabled(True)
        self.packet_save.setDisabled(True)
        self.iface_line.setText("INTERFACE")
        self.iface_select.clicked.connect(self.iface_Function)
        self.packet_start.clicked.connect(self.startFunction)
        self.packet_stop.clicked.connect(self.stopFunction)
        self.packet_save.clicked.connect(self.saveFunction)
        self.packet_load.clicked.connect(self.loadFunction)
        self.packet_list.cellClicked.connect(self.packet_detail)
        self.dialogs = list()
        self.cnt = 0
        self.rawpacket = []
        self.fontVar = QFont("consolas",10)
        ip = self.text_ip.text()
        port = self.text_port.text()
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind((ip, int(port)))
        s.listen(5)
        self.mod = run.run_run(parent = self, s = s)
        self.mod.mod_data.connect(self.modulation_text)
        self.btn_forward.setDisabled(True)
        self.btn_drop.setDisabled(True)
        self.btn_proxy.clicked.connect(self.modulation_proxy)
        self.btn_reset.clicked.connect(self.modulation_reset)
        self.btn_intercept.clicked.connect(self.intercept_clicked)
        self.btn_forward.clicked.connect(self.modulation_forward)
        self.btn_drop.clicked.connect(self.modulation_drop)

    def iface_Function(self) : #인터페이스 선택 버튼
        IfaceWindow = WindowClassIface()
        IfaceWindow.exec_()
        # res = IfaceWindow.tb_update()
        try:
            self.packet_start.setEnabled(True)
            self.iface = IfaceWindow.iface
            self.iface_line.setText(self.iface[0])
        except:
            self.packet_start.setDisabled(True)
            pass

    @pyqtSlot()
    def startFunction(self):
        self.packet_stop.setEnabled(True)
        self.packet_start.setDisabled(True)
        self.packet_save.setDisabled(True)
        self.th = Packet_view(parent = self, iface = self.iface[1])
        # self.th.rawpacket.connect(self._print)
        self.th.pac_view.connect(self.packet_tb_update)
        self.th.rawpacket.connect(self._save)
        self.th.start()
        self.th.working = True

    @pyqtSlot(list)
    def _save(self, packet):
        for i in packet:
            self.rawpacket.append(i)

    @pyqtSlot()
    def stopFunction(self):
        self.packet_save.setEnabled(True)
        self.packet_stop.setDisabled(True)
        self.packet_start.setEnabled(True)
        self.th.working = False

    @pyqtSlot(list)
    def packet_tb_update(self, packet):
        try:
            self.packet = packet
            self.packet_list.setRowCount(self.cnt+1)
            self.packet_list.setItem(self.cnt, 0, QTableWidgetItem(str(self.cnt)))
            self.packet_list.setItem(self.cnt, 1, QTableWidgetItem(packet[self.cnt][0]))
            self.packet_list.setItem(self.cnt, 2, QTableWidgetItem(packet[self.cnt][1]))
            self.packet_list.setItem(self.cnt, 3, QTableWidgetItem(packet[self.cnt][-1]))
            self.cnt += 1
        except:
            pass

    def packet_detail(self):
        self.pac_detail = ''
        print('미구현')

    def saveFunction(self):
        global fname
        fname = QFileDialog.getSaveFileName(self, "File Save", "untitle", ".pcap")
        fname =  ''.join(fname)
        save = pcapsave.Pcap(str(fname))
        for i in self.rawpacket:
            save.write(i)

    def loadFunction(self):
        global fname
        fname = QFileDialog.getOpenFileName(self, 'Open file')
        
        try:
            f = open(fname[0],"rb")
            with f:
                data = f.read()
            packet = pcapload.Pcap(data)
            print(packet)

        except:
            pass
    def modulation_proxy(self):
        ip = self.text_ip.text()
        port = self.text_port.text()
        proxy_on.proxy_on(ip, port)


    def modulation_reset(self):
    	proxy_off.proxy_off()
    	ip = self.text_ip.setText("")
    	port = self.text_port.setText("")
    	self.textEdit_8.setText("")
    	self.textEdit_7.setText("")


    def modulation_intercept(self):
    	ip = self.text_ip.text()
    	port = self.text_port.text()
    	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    	s.bind((ip, int(port)))
    	s.listen(5)
    	r = run.run_run()
    	th = Thread(target = r.exc(s, ), args =(s, ))
    	th.start()
    
    def intercept_clicked(self, data):
    	if self.btn_intercept.text()=='Intercept On':
    		self.mod.start()
    		self.mod.working = True
    		self.btn_forward.setEnabled(True)
    		self.btn_drop.setEnabled(True)
    		self.btn_intercept.setText('Intercept Off')
    	elif self.btn_intercept.text()=='Intercept Off':
    		self.mod.working = False
    		self.textEdit_8.setText('')
    		self.textEdit_7.setText('')
    		self.btn_forward.setDisabled(True)
    		self.btn_drop.setDisabled(True)
    		self.btn_intercept.setText('Intercept On')
			

    @pyqtSlot(bytes)
    def modulation_text(self, data):
    	self.textEdit_8.setText(data.decode('utf-8'))
    	self.data = binascii.hexlify(data)
    	self.data = str(self.data, 'ascii')
    	self.data = cut.cut_data(self.data)
    	self.textEdit_7.setCurrentFont(self.fontVar)
    	self.textEdit_7.setText(self.data)
    def modulation_forward(self, data):
	    # self.data = self.textEdit_8.setText(data)
	    self.run.run_run.send(self.data)
	    self.textEdit_8.setText()
    def modulation_drop(self, data):
    	self.textEdit_8.setText("")
    	self.textEdit_7.setText("")
    	if self.textEdit_8.setText(""):
    		self.modulation_text(data)
    		print(a)


def main():
    app = QApplication(sys.argv) #프로그램 실행 클래스
    MainWindow = WindowClassMain() #인스턴스 생성 
    MainWindow.show() #프로그램 화면 show
    app.exec_() #이벤트루프로 진입

if __name__ == "__main__" :
    main()