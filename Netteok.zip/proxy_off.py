import os

def proxy_off():
	close = os.popen('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" /v ProxyEnable /t REG_DWORD /d 0 /f')
	print(close.read()[:-1], end='')