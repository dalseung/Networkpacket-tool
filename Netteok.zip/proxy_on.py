import os

def proxy_on(ip, port):
	data= ip + ":" + port

	res1 = os.popen('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" /v ProxyServer /t REG_SZ /d {} /f'.format(data))

	res = os.popen('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" /v ProxyEnable /t REG_DWORD /d 1 /f')

	print(res.read()[:-1], end='')