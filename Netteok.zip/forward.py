import socket

def proxy_server(data):
   print(data)
   first_line = data.split(b'\n')[0]
   url = first_line.split(b' ')[1]
   http_pos = url.find(b"://")
   if (http_pos==-1):
      temp = url
   else:
      temp = url[(http_pos+3):]
   port_pos = temp.find(b":")
   webserver_pos = temp.find(b"/")
   if webserver_pos == -1:
      webserver_pos = len(temp)
   webserver = ""
   port = -1
   if (port_pos == -1 or webserver_pos < port_pos):
      port = 80
      webserver = temp[:webserver_pos]
   else:
      port = int((temp[(port_pos+1):])[:webserver_pos-port_pos-1])
      webserver = temp[:port_pos]
   host = webserver.decode('utf-8')
   s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   s.connect((host, port))
   s.send(data)

   s.close()
   print('성공')