from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
import sys, dpkt, pcap, socket, re, time

icmp_type = {0:'Echo Reply', 3:'Destination Network Unreachable', 5:'Redirect', 8:'Echo Request',11:'TTL expired in trans'}
protocols = {1:'ICMP',6:'TCP',7:'ECHO',17:'UDP',20:'FTP',21:'FTP',22:'SSH',23:'Telnet',25:'SMTP',53:'DNS',67:'DHCP',68:'DHCP',69:'TFTP',80:'HTTP',110:'POP3',143:'IMAP4',161:'SNMP',443:'HTTPS',520:'RIP'}

class Packet_view(QThread):

    rawpacket = pyqtSignal(list)
    pac_view = pyqtSignal(list)

    def __init__(self, parent=None, iface=None):
        super().__init__()
        self.main = parent
        self.working = True
        self.iface = iface
        self.cnt = 0
        self.raw = []
        self.packet_detail = []
        self.packet_view = []
        if self.iface != None:
            self.pc = pcap.pcap(name=self.iface)

    def __del__(self):
        self.wait()

    def run(self):
        while self.working:
            for t, p in self.pc:
                self.rawpacket.emit(self.raw)
                self.raw.append(p)
                self.packet_detail.append([])
                self.packet_view.append([])
                self.ether(p)
                time.sleep(0.1)
                self.pac_view.emit(self.packet_view)
                self.cnt += 1
                if self.working == False:
                    break

    def packet_load(self, packet):
        self.raw = packet
        for p in packet:
            self.packet_detail.append([])
            self.packet_view.append([])


    def mac_addr(self, address):
        return ':'.join('%02x' % dpkt.compat.compat_ord(b) for b in address) #%02x : 앞의 빈자리를 0으로 채우기


    def inet_to_str(self, inet):
        try:
            return socket.inet_ntop(socket.AF_INET, inet)
        except ValueError:
            return socket.inet_ntop(socket.AF_INET6, inet)


    def ether(self, p):
        eth = dpkt.ethernet.Ethernet(p)
        ether_frame = '''<Ethernet Frame>
Source MAC Address : %s
Destination MAC Address : %s
Ether Type : %s
''' % (self.mac_addr(eth.src), self.mac_addr(eth.dst), str(hex(eth.type)))
        self.packet_detail[self.cnt].append(ether_frame)
        try:
            if(eth.type == 0x800):
                self.IPv4(eth.data)
            elif(eth.type == 0x86DD):
                self.IPv6(eth.data)
            elif(eth.type == 0x806):
                self.ARP(eth.data)
            else:
                print("지원하지 않는 프로토콜입니다.")
        except:     
            pass


    def IPv4(self, ip):
        self.packet_view[self.cnt].append(str(self.inet_to_str(ip.src)))
        self.packet_view[self.cnt].append(str(self.inet_to_str(ip.dst)))
        ipv4_frame = '''<IPv4 Frame>
Version : %s
Length : %s
Type of Service : %s
Total Length : %s
Identification : %s (%s)
Flags : %s %s %s
Fragment Offest : %s
Time to Live : %s
Protocol : %s (%s)
Header Checksum : %s
Source IP Address : %s
Destination IP Address : %s\n
''' % (ip.v, ip.hl, ip.tos, ip.len, hex(ip.id), ip.id, ip.rf, ip.df, ip.mf, ip.offset, ip.ttl, ip.p, protocols[ip.p], hex(ip.sum), self.inet_to_str(ip.src), self.inet_to_str(ip.dst))
        if ip.opts != "":
            ipv4_frame += 'Options : '+ str(ip.opts)
        if(ip.p == 6):
            self.TCP(ip.data)
        elif(ip.p == 17):
            self.UDP(ip.data)
        self.packet_detail[self.cnt].append(ipv4_frame)

    def IPv6(self, ip):
        self.packet_view[self.cnt].append(str(self.inet_to_str(ip.src)))
        self.packet_view[self.cnt].append(str(self.inet_to_str(ip.dst)))
        ipv6_frame = '''<IPv6 Frame>
Version : %s
Traffic class : %s
Flow label : %s
Payload length : %s
Next header : %s
Hop limit : %s
Source IP Address : %s
Destination IP Address : %s
''' % (ip.v, hex(ip.fc), hex(ip.flow), ip.plen, ip.nxt, ip.hlim, self.inet_to_str(ip.src), self.inet_to_str(ip.dst))
        if(nxt == 6):
            self.TCP(ip.data)
        elif(nxt == 17):
            self.UDP(ip.data)
        self.packet_detail[self.cnt].append(ipv6_frame)


    op_list = ["tmp", "request", "reply"]
    def ARP(self, arp):
        self.packet_view[self.cnt].append(str(self.mac_addr(arp.sha)))
        self.packet_view[self.cnt].append(str(self.mac_addr(arp.tha)))
        self.packet_view[self.cnt].append('ARP')
        arp_frame = '''<ARP Frame>
Hardware Type : Ethernet  (%s)
Protocol Type : %s
Hardware size : %s
Protocol size : %s 
Opcode: %s (%s)
Sender MAC Address : %s
Sender IP Address : %s
Target MAC Address : %s
Target IP Address : %s
''' % (str(arp.hrd), str(hex(arp.pro)), str(arp.hln), str(arp.pln), str(op_list[arp.op]), str(arp.op), str(self.mac_addr(arp.sha)), str(self.inet_to_str(arp.spa)), str(self.mac_addr(arp.tha)), str(self.inet_to_str(arp.tpa)))
        self.packet_detail[self.cnt].append(arp_frame)

    def UDP(self, udp):
        self.packet_view[self.cnt].append('UDP')
        udp_frame = '''<UDP Frame>
Source port : %s
Destination port : %s
Length : %s
Chceksum : %s
''' % (str(udp.sport), str(udp.dport), str(udp.ulen), str(udp.sum))
        self.packet_detail[self.cnt].append(udp_frame)

    def TCP(self, tcp):
        self.packet_view[self.cnt].append('TCP')
        tcp_frame = '''<TCP Frame>
Source port : %s
Destination port : %s
Sequence Number : %s
Acknowledgment Number : %s
Offset : %s
Flags : %s
Window size : %s
Checksum : %s
Urgent pointer : %s
Option and Padding : %s
Reserved
''' % (str(tcp.sport), str(tcp.dport), str(tcp.seq), str(tcp.ack), str(tcp.off), str(tcp.flags), str(tcp.win), str(tcp.sum), str(tcp.urp), str(tcp.opts))
        if(tcp.dport == 80):
            self.HTTP_request(dpkt.http.Request(tcp.data))
        if(tcp.sport == 80):
            self.HTTP_response(dpkt.http.Response(tcp.data))
        self.packet_detail[self.cnt].append(tcp_frame)

    def HTTP_request(self, http):
        self.packet_view[self.cnt].append('HTTP')
        http_frame = '''<HTTP Request Frame>
%s
''' % (http)
        self.packet_detail[self.cnt].append(http_frame)

    def HTTP_response(self, http):
        self.packet_view[self.cnt].append('HTTP')
        http_frame = '''<HTTP Response Frame>
%s
''' % (http)
        self.packet_detail[self.cnt].append(http_frame)