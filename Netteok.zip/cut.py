def cut_data(data):
	d = ""
	i = 1
	sta = 0
	fin = 2

	while fin <= len(data):
		d += data[sta:fin]
		sta += 2
		fin += 2
		if (fin-2) == 32 * i:
			d += "\n"
			i += 1
		else:
			d += " "

	return d