import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5 import uic, QtCore, QtGui, QtWidgets
from winreg import *
import dpkt, pcap, protocol, pcapsave
from p_main import *

devs = pcap.findalldevs()
net = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\NetworkCards"
reg = ConnectRegistry(None,HKEY_LOCAL_MACHINE)
key = OpenKey(reg, net)
lst = []
iface = []
for i in range(1024):
    try:
        keyname = EnumKey(key,i)
        try:
            for j in range(1024):
                route = net + '\\' + str(keyname)
                key2 = OpenKey(reg, route)
                a, b, c = EnumValue(key2, j)
                if 'Wireless' in str(b):
                    lst.append('WIFI')
                elif 'Realtek PCIe GbE Family Controller' in str(b):
                    lst.append('Ethernet')
                else:
                    lst.append(b)
        except:
            pass
    except:
        pass

form_class_iface = uic.loadUiType("untitlediface2.ui")[0]
#화면을 띄우는데 사용되는 Class 선언
class WindowClassIface(QDialog, form_class_iface):
    def __init__(self, parent=None):
        super(WindowClassIface, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle("Netteock")
        self.setWindowIcon(QIcon("네떡.png"))
        self.iface=[]
        self.tb_update(lst, devs) #Chatlog 테이블 업데이트
        self.tb_iface.cellDoubleClicked.connect(self.test)

    def tb_update(self, lst, devs):
    	self.tb_iface.setRowCount(len(lst)/2)
        
    	cnt = 0

    	for i in range(len(devs)):
    		for j in range(0, len(lst), 2):
    			if lst[j] == devs[i][12:]:
    				self.tb_iface.setItem(cnt, 0, QTableWidgetItem(str(i)))
    				self.tb_iface.setItem(cnt, 1, QTableWidgetItem(str(lst[j+1])))
    				self.tb_iface.setItem(cnt, 2, QTableWidgetItem(str(devs[i])))
    				cnt += 1

    def test(self):
        # print(self.tb_iface.selectedItems().text())
        self.iface = list(map(lambda x : x.text(), self.tb_iface.selectedItems()))[1:]
        # protocol.interface_name(iface[1])
        self.close()
        #self.mainWindow.fileLine.setText
