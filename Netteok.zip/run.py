import socket, sys
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
import time

ip=0
port=0
max_conn = 5
buffer_size = 8192

class run_run(QThread):

	mod_data = pyqtSignal(bytes)

	def __init__(self, parent=None , s=None):
		super().__init__()
		self.main = parent
		self.data = b''
		self.s = s
		self.working = True

	def __del__(self):
		self.wait()

	def run(self):
		while self.working:
			time.sleep(1)
			conn, addr = self.s.accept()
			self.data = conn.recv(8192)
			first_line = self.data.split(b'\n')[0]
			url = first_line.split(b' ')[1]
			http_pos = url.find(b"://")
			if (http_pos==-1):
				temp = url
			else:
				temp = url[(http_pos+3):]
			port_pos = temp.find(b":")
			webserver_pos = temp.find(b"/")
			if webserver_pos == -1:
				webserver_pos = len(temp)
			webserver = ""
			dport = -1
			if (port_pos == -1 or webserver_pos < port_pos):
				dport = 80
				webserver = temp[:webserver_pos]
			else:
				dport = int((temp[(port_pos+1):])[:webserver_pos-port_pos-1])
				webserver = temp[:port_pos]

			if dport == 80:
				print("80포트")
				#print()
				#print(self.data.decode('utf-8'))
				self.mod_data.emit(self.data)
				print(self.mod_data)
				# self.proxy_server(webserver, dport, conn, addr, self.data)		
			else:
				print("443포트")
				self.proxy_server(webserver, dport, conn, addr, self.data)

			

	def proxy_server(self, host, port, conn, addr, data):
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		s.connect((host, port))
		s.send(self.data) #프록시 서버에서 서버로 데이터를 전송
		

		if port == 80:
			reply = s.recv(8192) #서버에서 프록시로 응답을 받아옴
			print()
			print("===========Host Reply===========")
			print(reply)
			if(len(reply) > 0):
				conn.send(reply) #프록시에서 클라이언트에게 응답을 전송
		else:
			conn.send(self.data)
		s.close()
		conn.close()
